import styles from './Form.module.css'

function Paypal() {

    return(
        <>
        <div>
            <p>You will be redirected to Paypal for payment.</p>
        </div>
        </>
    );
}

export default Paypal